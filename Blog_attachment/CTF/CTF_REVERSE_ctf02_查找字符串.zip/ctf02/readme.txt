基于对话框MFC框架开发，使用EDIT控制特性隐藏Flag，可借助spy4win之类窗体工具找出Flag。
程序加UPX壳，已对壳信息混淆处理，PEiD无法识别出壳信息。
DLL 依赖情况如图所示。
